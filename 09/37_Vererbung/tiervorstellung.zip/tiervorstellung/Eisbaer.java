/**
 * Klasse Eisbaer <br>
 *
 * Kap. 7.1 Arbeitsauftrag 2
 */
class Eisbaer extends Tier
{
    Eisbaer()
    {
        art = "Eisbär";
        futter = "Fisch";
    }
}
