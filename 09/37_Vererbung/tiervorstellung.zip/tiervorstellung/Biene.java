/**
 * Klasse Biene <br>
 *
 * Kap. 7.1 Arbeitsauftrag 2
 */
class Biene extends Tier
{
    Biene()
    {
        art = "Biene";
        futter = "Pollen";
    }
}
