import greenfoot.World;

/**
 * Projekt zu 7.1 <br>
 *
 * Klasse Tierwelt <br>
 * Hier müssen die Objekte erzeugt und in die Welt eingefügt werden, um sichtbar zu sein.
 */
public class Tierwelt extends World
{
    public Tierwelt()
    {
        super(10, 6, 60);
        // erzeugt ein Objekt der Klasse Tier und fügt es an der Stelle (3|1) ein
        addObject(new Tier(), 3, 1);
        // erzeugt ein Objekt der Klasse Biene und fügt es an der Stelle (5|3) ein
        addObject(new Biene(), 5, 3);
        // erzeugt ein Objekt der Klasse Eisbär und fügt es an der Stelle (7|2) ein
        addObject(new Eisbaer(), 7, 2);
    }
}
