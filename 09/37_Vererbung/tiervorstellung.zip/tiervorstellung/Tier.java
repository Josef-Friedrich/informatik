import greenfoot.Actor;

/**
 * Klasse Tier
 */
class Tier extends Actor
{
    String art;
    String futter;

    Tier()
    {
        art = "Tier";
        futter = "";
    }

    void stelleVor()
    {
        String text = "Ich bin ein " + art + ", ich fresse gerne " + futter + ".";
        DrawingUtil.showText(this, text, 300);
    }
}
