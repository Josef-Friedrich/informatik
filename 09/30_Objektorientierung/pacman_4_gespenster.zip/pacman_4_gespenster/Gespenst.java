import greenfoot.Actor;

public class Gespenst extends Actor {

    private final char farbe;
    public int startX;
    public int startY;
    private String richtung;
    private double geschwindigkeit;

    private int bildNo = 1;

    public Gespenst(int startX, int startY, char farbe, String richtung, double geschwindigkeit) {
        this.startX = startX;
        this.startY = startY;
        this.farbe = farbe;
        this.richtung = richtung;
        this.geschwindigkeit = geschwindigkeit;
        setzeBild();
    }

    private int konvertiereRichtung(String richtung) {
        int r;

        switch (richtung) {
            case "O":
                r = 0;
                break;
            case "SO":
                r = 45;
                break;
            case "S":
                r = 90;
                break;
            case "SW":
                r = 135;
                break;
            case "W":
                r = 180;
                break;
            case "NW":
                r = 225;
                break;
            case "N":
                r = 270;
                break;
            case "NO":
                r = 315;
                break;
            default:
                r = 0;
                break;
        }
        return r;
    }

    private void setzeBild() {
        if (bildNo == 1) {
            bildNo = 2;
        } else {
            bildNo = 1;
        }
        this.setImage("" + farbe + bildNo + ".png");
    }

    public void act() {
        if (isAtEdge()) {
            getWorld().removeObject(this);
            return;
        }

        setRotation(konvertiereRichtung(this.richtung));
        move((int) this.geschwindigkeit);
        setRotation(0);
        setzeBild();
    }
}