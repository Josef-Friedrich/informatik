import greenfoot.World;
import greenfoot.Color;
import greenfoot.GreenfootImage;

public class MyWorld extends World {
    public MyWorld() {
        super(600, 400, 1);
        GreenfootImage b = getBackground();
        b.setColor(Color.BLACK);
        b.fillRect(0,0,getWidth(),getHeight());
        prepare();
    }

    private void prepare() {
        Gespenst1 g1 = new Gespenst1();
        if (g1.erscheine) {
            addObject(new Gespenst(g1.startX, g1.startY, g1.farbe, g1.richtung, g1.geschwindigkeit), g1.startX, g1.startY);
        }

        Gespenst2 g2 = new Gespenst2();
        if (g2.erscheine) {
            addObject(new Gespenst(g2.startX, g2.startY, g2.farbe, g2.richtung, g2.geschwindigkeit), g2.startX, g2.startY);
        }

        Gespenst3 g3 = new Gespenst3();
        if (g3.erscheine) {
            addObject(new Gespenst(g3.startX, g3.startY, g3.farbe, g3.richtung, g3.geschwindigkeit), g3.startX, g3.startY);
        }

        Gespenst4 g4 = new Gespenst4();
        if (g4.erscheine) {
            addObject(new Gespenst(g4.startX, g4.startY, g4.farbe, g4.richtung, g4.geschwindigkeit), g4.startX, g4.startY);
        }
    }
}
