import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Klasse Schueler <br>
 * Kap. 5.1, Arbeitsauftrag 4c), Aufgaben 1 und 2
 */

public class Schueler extends Actor
{
    /* Ab hier ist Platz für neue Methoden.
     * Aktuell sind noch keine programmiert.
     * Methoden dürfen nicht nach der letzten "}" stehen.
     */
    
    
    
}