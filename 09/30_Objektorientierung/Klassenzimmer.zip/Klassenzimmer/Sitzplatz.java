import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Klasse Sitzplatz <br>
 * Kap. 5.1, Aufgabe 3b) 
 */

public class Sitzplatz extends Actor
{

}
