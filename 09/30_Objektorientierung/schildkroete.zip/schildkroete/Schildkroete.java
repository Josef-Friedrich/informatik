import greenfoot.*; // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * Eine einfache Schildkröte
 *
 * @author Poul Henriksen, Paul Clark @sandtreader
 * @version 1.0.2
 */
public class Schildkroete extends Actor {
  /** Whether the turtle should paint or not. */
  private boolean penDown;

  /** Colour of the pen. */
  private String color = "schwarz";

  /** The direction the turtle is facing. */
  private double direction;

  /** The x location. */
  private double x;

  /** The y location. */
  private double y;

  /** The maximum value that the direction can have. */
  private final static double MAX_ANGLE = 360;

  /** Image used when the pen is up */
  private GreenfootImage penUpImage;

  /** Image used when the pen is down */
  private GreenfootImage penDownImage;

  public Schildkroete() {
    penUpImage = getImage();
    penDownImage = new GreenfootImage(penUpImage);
    zeichneStift(penDownImage);
  }

  /**
   * Turns the turtle.
   *
   */
  public void drehe(double winkel) {
    direction = direction + winkel;
    if (direction > MAX_ANGLE) {
      direction = direction % MAX_ANGLE;
    }
    setRotation((int) direction);
  }

  /**
   * Force override of Actor::turn(int) as well
   */
  private void drehe(int winkel) {
    drehe((double) winkel);
  }

  /**
   * Moves the turtle to the given position.
   */
  private void geheZu(double newX, double newY) {
    if (penDown) {
      zeichneLinie(x, y, newX, newY);
    }
    x = newX;
    y = newY;
    setzeOrt(x, y);
  }

  /**
   * Die Schilkröte geht eine mit dem Parameter entfernung angegebene Strecke.
   *
   * @param entfernung Die Entfernung als Gleitkommazahl mit doppelter
   * Genauigkeit.
   */
  public void gehe(double entfernung) {
    double directionRad = Math.toRadians(direction);
    double xDist = entfernung * Math.cos(directionRad);
    double yDist = entfernung * Math.sin(directionRad);
    geheZu(x + xDist, y + yDist);
  }

  /**
   * Die Schilkröte geht eine mit dem Parameter entfernung angegebene Strecke.
   *
   * @param entfernung Die Entfernung als Ganzzahl angegeben.
   */
  public void gehe(int entfernung) {
    gehe((double) entfernung);
  }

  public void hebeStift() {
    penDown = false;
    setImage(penUpImage);
  }

  public void senkeStift() {
    penDown = true;
    setImage(penDownImage);
  }

  /**
   * Setze die Farbe des Stifts. Diese Farben können verwendet werden: "rot",
   * "schwarz", "blau", "gelb", "grün", "violett", "weiß"
   */
  public void setzeFarbe(String farbe) {
    color = farbe;
    zeichneStift(penDownImage);
  }

  /**
   * Translate a String into a Color
   */
  private Color decode(String colorString) {
    if (colorString.equals("rot"))
      return Color.RED;
    else if (colorString.equals("schwarz"))
      return Color.BLACK;
    else if (colorString.equals("blau"))
      return Color.BLUE;
    else if (colorString.equals("gelb"))
      return Color.YELLOW;
    else if (colorString.equals("grün"))
      return Color.GREEN;
    else if (colorString.equals("violett"))
      return Color.MAGENTA;
    else if (colorString.equals("weiß"))
      return Color.WHITE;
    else
      return Color.BLACK;
  }

  /**
   * We need to make sure that our own representaion of the location is the
   * same as the World's.
   */
  protected void addedToWorld(World world) {
    x = getX();
    y = getY();
  }

  /**
   * Draw a line between to point with the current colour.
   */
  private void zeichneLinie(double x1, double y1, double x2, double y2) {
    GreenfootImage image = getWorld().getBackground();
    Color awtColor = decode(color);
    image.setColor(awtColor);
    image.drawLine((int) Math.ceil(x1), (int) Math.ceil(y1), (int) Math.ceil(x2), (int) Math.ceil(y2));
  }

  /**
   * Draw the pen on the back of the turtle with the correct colour
   */
  private void zeichneStift(GreenfootImage image) {
    double halfWidth = image.getWidth() / 2.;
    double halfHeight = image.getHeight() / 2.;
    int penWidth = (int) halfWidth / 2;
    int penHeight = (int) halfHeight / 2;
    int penX = (int) (halfWidth - penWidth / 2);
    int penY = (int) (halfHeight - penHeight / 2);
    Color awtColor = decode(color);
    image.setColor(awtColor);
    image.fillOval(penX - 3, penY - 1, penWidth, penHeight);
  }

  /**
   * Set the location of the turtle.
   */
  private void setzeOrt(double x, double y) {
    this.x = x;
    this.y = y;
    super.setLocation((int) Math.floor(x), (int) Math.floor(y));
  }

  /**
   * We need to override this method, so we can interactively move objects.
   * This method should not be used by subclasses. Use the
   * setLocation(double x, double y) instead
   */
  private void setzeOrt(int x, int y) {
    this.x = x;
    this.y = y;
    super.setLocation(x, y);
  }
}
