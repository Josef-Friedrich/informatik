import greenfoot.*;  // (World, Actor, GreenfootImage, and Greenfoot)

/**
 * Eine weiße Welt, auf der die Schildkröte malen kann.
 *
 * @author Poul Henriksen
 * @version 1.0.1
 */
public class SchildkroetenWelt extends World
{
    /**
     * Creates a new world with 800x600 cells and
     * with a cell size of 1x1 pixels
     */
    public SchildkroetenWelt() {
        super(800,600, 1);
        getBackground().setColor(Color.WHITE);
        getBackground().fill();
    }
}
