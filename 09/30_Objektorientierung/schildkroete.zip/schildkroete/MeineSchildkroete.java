class MeineSchildkroete extends Schildkroete
{
    void zeichneDreieck() {
        senkeStift();
        gehe(100);
        drehe(120);
        gehe(100);
        drehe(120);
        gehe(100);
        drehe(120);
    }
}
