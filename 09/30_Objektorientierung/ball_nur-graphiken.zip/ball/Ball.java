import greenfoot.*;

public class Ball extends Actor
{

    public void act()
    {

    }
}
