import greenfoot.*;

public class Spielfeld extends World
{
    public Spielfeld()
    {
        super(800, 600, 1);
        addObject(new Ball(),400,300);
    }
}
