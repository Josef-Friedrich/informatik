https://de.freepik.com/vektoren-kostenlos/kollektion-von-sportelementen_1060670.htm

Designed by Terdpongvector / Freepik


Rasen: https://media.istockphoto.com/vectors/lawn-grass-seamless-pattern-in-summervector-illustration-cartoon-vector-id1350483423?b=1&k=20&m=1350483423&s=170667a&w=0&h=_4sNnjnC_vZSj364IPhj4molRoKCn_mitagRnwH3MjY=
