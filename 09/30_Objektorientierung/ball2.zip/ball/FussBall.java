import greenfoot.*;

public class FussBall extends Ball
{
    FussBall()
    {
        setzeBild("fuss");
        setzeGeschwindigkeit(15);
        setzeRichtung(90);
    }
}
