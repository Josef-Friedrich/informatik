import greenfoot.*;

public class FussBallFeld extends Spielfeld
{
    public FussBallFeld()
    {
        addObject(new FussBall(), 200, 300);
        addObject(new FussBall(), 400, 300);
        addObject(new FussBall(), 600, 300);
    }
}
