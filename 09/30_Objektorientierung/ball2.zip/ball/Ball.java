import greenfoot.*;  

public class Ball extends Actor
{
    String bildName; 
    int geschwindigkeit;
    int richtung;

    void setzeBild(String name) 
    {
        bildName = name;
        setImage(name + ".png");
    }

    void setzeGeschwindigkeit(int geschwindigkeit) 
    {
        this.geschwindigkeit = geschwindigkeit;
    }

    void setzeRichtung(int richtung) 
    {
        this.richtung = richtung;
        setRotation(richtung);
    }

    private void pralleAb()
    {
        if (isAtEdge())
        {
            turn(Greenfoot.getRandomNumber(360));
        }
    }

    public void act() 
    {
        pralleAb();
        move(geschwindigkeit);
    }    
}