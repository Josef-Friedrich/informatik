import greenfoot.*; // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class Spielfeld extends World
{
    Ball ball;
    Spieler spielerLinks;
    Spieler spielerRechts;

    public Spielfeld()
    {
        super(800, 500, 1);

        ball = new Ball();
        addObject(ball, 400, 250);

        spielerLinks = new Spieler(1, "Spieler_Blau.png");
        addObject(spielerLinks, 150, 250);

        spielerRechts = new Spieler(3, "Spieler_Rot.png");
        addObject(spielerRechts, 650, 250);
    }
}
