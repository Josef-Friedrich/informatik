public class Gespenst3 {
  int startX = 536;
  int startY = 336;
  char farbe = 'p';
  String richtung = "NW";
  double geschwindigkeit = 2;
  boolean erscheine = true;
}
