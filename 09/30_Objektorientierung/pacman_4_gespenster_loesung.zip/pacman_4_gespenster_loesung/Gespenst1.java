class Gespenst1 {
    int startX = 64;
    int startY = 64;
    char farbe = 'r';
    String richtung = "SO";
    double geschwindigkeit = 2;
    boolean erscheine = true;
}
