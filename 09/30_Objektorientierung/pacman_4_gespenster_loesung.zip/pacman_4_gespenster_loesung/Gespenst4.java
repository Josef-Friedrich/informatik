class Gespenst4 {
    int startX = 64;
    int startY = 336;
    char farbe = 'o';
    String richtung = "NO";
    double geschwindigkeit = 2;
    boolean erscheine = true;
}
