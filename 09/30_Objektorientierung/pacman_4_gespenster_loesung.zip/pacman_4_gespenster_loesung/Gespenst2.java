class Gespenst2 {
    int startX = 536;
    int startY = 64;
    char farbe = 'b';
    String richtung = "SW";
    double geschwindigkeit = 2;
    boolean erscheine = true;
}
