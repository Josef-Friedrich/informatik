import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Klasse Auftriebszone <br>
 * Enthält weder Attribute noch Methoden.
 */

public class Auftriebzone extends Actor
{
       
}
