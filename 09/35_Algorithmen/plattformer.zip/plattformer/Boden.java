import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Klasse Boden <br>
 * Enthält weder Attribute noch Methoden.
 */

public class Boden extends Actor
{
       
}
