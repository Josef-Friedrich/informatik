import greenfoot.*;

/**
 * Nach Buchner Projekt zu Kap. 6.2.
 *
 * Arbeitsauftrag 2, Aufgabe 1
 */
public class Spielwelt extends World
{
    int timer = 0;
    int anzahlGefresseneLaeuse = 0;

    public Spielwelt()
    {
        // erzeugt eine Welt, 800x600 Zellen, Seitenlänge jeweils 1 Pixel
        super(800, 600, 1);
        // fügt Marienkäfer der Welt hinzu
        addObject(new Marienkaefer(this), 300, 300);

        // Aufgabe 2 c)








    }

    void fülleMitLäusen()
    {
        // Aufgabe 1






    }

    void fügeLausEin()
    {
        int x;
        int y;
        // verhindert, dass die Laus in die linke Hecke gesetzt wird
        x = Greenfoot.getRandomNumber(600) + 100;
        y = Greenfoot.getRandomNumber(600);
        // Aufgabe 3c









        // fügt eine Blattlaus an der Stelle (x, y) ein
        addObject(new Blattlaus(), x, y);
    }

    /**
     * Der Programmtext ab hier braucht für die Bearbeitung der Arbeitsaufträge und Aufgaben weder
     * gelesen noch verstanden zu werden.
     *
     * erhöht nach 1200 Zeitschritten die Zahl der Blattläuse wieder auf 30
     */
    public void act() //
    {
        timer = timer - 1;
        if (timer <= 0)
        {
            fülleMitLäusen();
            timer = 1200;
        }
        aktualisiereTexte();
    }

    /**
     * erzeugt alle Texte und zeigt sie an
     */
    void aktualisiereTexte()
    {
        showText("Timer: " + timer, 300, 10);
        showText("Läuse gefressen: " + anzahlGefresseneLaeuse, 300, 30);
        showText("Läuse übrig: " + zähleLäuse(), 300, 50);
        if (zähleLäuse() == 0)
        {
            showText("Gewonnen!", 300, 70);
            Greenfoot.stop();
        }
    }

    /**
     * fügt einen Busch in die Welt ein
     */
    void fügeBuschHinzu(int xPos, int yPos)
    {
        Busch baumstumpf = new Busch();
        addObject(baumstumpf, xPos, yPos);
    }

    int zähleLäuse()
    {
        return getObjects(Blattlaus.class).size();
    }

    double berechneLausDistanz(int x, int y)
    {
        int lausNr = 0;
        double minDistanz = Double.POSITIVE_INFINITY;;

        while (lausNr < zähleLäuse())
        {
            Blattlaus aktuelleLaus = getObjects(Blattlaus.class).get(lausNr);
            int dx = x - aktuelleLaus.getX();
            int dy = y - aktuelleLaus.getY();
            double aktuelleDistanz = Math.sqrt(dx * dx + dy * dy);

            if (aktuelleDistanz < minDistanz)
            {
                minDistanz = aktuelleDistanz;
            }
            lausNr = lausNr + 1;
        }
        return minDistanz;
    }
}
