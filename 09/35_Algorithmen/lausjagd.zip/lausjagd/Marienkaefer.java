import greenfoot.*;

/**
 * Klasse Marienkäfer <br>
 *
 * Enthält unter anderem die Steuerung des Marienkäfer-Objekts.
 */
public class Marienkaefer extends Actor
{
    Spielwelt welt;

    Marienkaefer(Spielwelt neueWelt)
    {
        welt = neueWelt;
    }

    void dreheRechts()
    {
        setRotation(getRotation() + 5);
    }

    void dreheLinks()
    {
        setRotation(getRotation() - 5);
    }

    void geheNachVorne()
    {
        move(3);
    }

    void drehe90Links()
    {
        // Aufgabe 4(a)





    }

    void drehe90Rechts()
    {
        // Aufgabe 4(a)






    }



    void geheNachOben()
    {
        // Aufgabe 4(b)






    }

    void geheQuadrat()
    {
        // Aufgabe 5(a)







    }

    void laufe300Schritte()
    {
        // Aufgabe 5(b)







    }


    /**
     * Der Programmtext ab hier braucht für die Bearbeitung der Arbeitsaufträge und Aufgaben weder
     * gelesen noch verstanden zu werden.
     */
    public void act()
    {
        if (Greenfoot.isKeyDown("left"))
        {
            dreheLinks();
        }

        if (Greenfoot.isKeyDown("right"))
        {
            dreheRechts();
        }

        if (Greenfoot.isKeyDown("up"))
        {
            geheNachVorne();
        }

        if (getX() < 100)
        {
            setLocation(100, getY());
        }

        if (getX() > 700)
        {
            setLocation(700, getY());
        }

        if (isTouching(Blattlaus.class))
        {
            this.removeTouching(Blattlaus.class);
            welt.anzahlGefresseneLaeuse = welt.anzahlGefresseneLaeuse + 1;
        }
    }
}
