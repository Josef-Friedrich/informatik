import greenfoot.*;

/**
 * Klasse Busch <br>
 *
 * Diese Klasse enthält weder Attribute noch Methoden.
 */
public class Busch extends Actor
{

}
