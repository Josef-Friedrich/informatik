import greenfoot.*; // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Klasse Blattlaus <br>
 *
 * Enthält unter anderem die Steuerung der Blattlaus-Objekte. <br>
 *
 * Der Programmtext dieser Klasse braucht für die Bearbeitung der Arbeitsaufträge und Aufgaben weder
 * gelesen noch verstanden zu werden.
 */
public class Blattlaus extends Actor
{
    public void act()
    {
        double zufall = Math.random();
        Blattlaus laus = gibBlattlaus();
        Marienkaefer käfer = gibKäfer();
        if (laus != null && zufall < 0.3)
        {
            int rotation = berechneWinkelZwischen(this, laus);
            double distanz = berechneDistanzZwischen(this, laus);

            if (distanz > 15)
            {
                setRotation(rotation);
                move(1);
            }
            else
            {
                setRotation(rotation + 180);
                move(1);
            }
        }
        else
        {
            if (zufall < 0.8 && berechneDistanzZwischen(this, käfer) < 100)
            {
                int rotation = berechneWinkelZwischen(this, gibKäfer());
                setRotation(rotation + 180);
                move(3);
            }
            else
            {
                setRotation(Greenfoot.getRandomNumber(360));
                move(2);
            }
        }

        if (getX() < 100)
        {
            setLocation(100, getY());
        }

        if (getX() > 700)
        {
            setLocation(700, getY());
        }
    }

    Marienkaefer gibKäfer()
    {
        return getWorld().getObjects(Marienkaefer.class).get(0);
    }

    Blattlaus gibBlattlaus()
    {
        double kleinsteEntfernung = Double.POSITIVE_INFINITY;
        Blattlaus nächste = null;
        for (Blattlaus laus : getWorld().getObjects(Blattlaus.class))
        {
            if (laus != this)
            {
                double dist = berechneDistanzZwischen(this, laus);
                if (dist < kleinsteEntfernung)
                {
                    kleinsteEntfernung = dist;
                    nächste = laus;
                }
            }
        }
        return nächste;
    }

    double berechneDistanzZwischen(Actor actor1, Actor actor2)
    {
        int dx = actor1.getX() - actor2.getX();
        int dy = actor1.getY() - actor2.getY();
        return Math.sqrt(dx * dx + dy * dy);
    }

    int berechneWinkelZwischen(Actor start, Actor dest)
    {
        int dx = dest.getX() - start.getX();
        int dy = dest.getY() - start.getY();
        return berechneRotationAusVektor(dx, dy);
    }

    int berechneRotationAusVektor(int dx, int dy)
    {
        // -dy: Greenfoot Koordinaten sind gespiegelt
        double winkelPolar = Math.atan2(-dy, dx);
        // Polar -> Grad
        double winkelGrad = (winkelPolar / Math.PI * 180 + 360) % 360;
        // Greenfoot Rotation ist gespiegelt
        double winkelGreenfoot = 360 - winkelGrad;
        return (int) winkelGreenfoot;
    }
}
